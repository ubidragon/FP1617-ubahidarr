package fp.audiovisuales;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

import fp.utiles.Ficheros;

public class GestorSeriesFavoritasImpl2 extends GestorSeriesFavoritasImpl {

	public GestorSeriesFavoritasImpl2(String id, String nombre, Set<SerieTV> seriesTV) {
		super(id, nombre, seriesTV);
	}

	public GestorSeriesFavoritasImpl2(String id, String nombre) {
		super(id, nombre);
	}

	/**
	 * @return Devuelve la serie m�s popular del g�nero dado como par�metro . Si
	 *         no hay ninguna serie de ese g�nero se eleva
	 *         NoSuchElementException
	 */

	public SerieTV getSerieMasPopular(String genero) {

		Comparator<SerieTV> cmp = Comparator.comparing(x -> x.getPopularidad());

		return getSeriesTV().stream().filter((SerieTV x) -> x.getGeneros().contains(genero)).max(cmp)
				.orElseThrow(NoSuchElementException::new);
	}

	/**
	 * @param nombreFichero
	 * @param g�nero
	 * 
	 * @return Genera un fichero con el nombre dado como par�metro que contiene
	 *         informaci�n sobre las series del gestor que pertenezcan al g�nero
	 *         indicado como par�metro. En cada l�nea del fichero se mostrar� la
	 *         siguiente informaci�n: el nombre de la serie, el a�o de la
	 *         emisi�n entre par�ntesis, el n�mero de temporadas y el de
	 *         episodios. El fichero estar� ordenado por a�o de emisi�n, y a
	 *         igualdad de a�o por popularidad.
	 */

	public void guardaEnFicheroOrdenados(String nombreFichero, String genero) {

		Comparator<SerieTV> cmp = Comparator.comparing((SerieTV x) -> x.getFechaPrimeraEmision().getYear())
				.thenComparing(SerieTV::getPopularidad);

		Set<String> objetos = getSeriesTV().stream().filter(x -> x.getGeneros().contains(genero)).sorted(cmp)
				.map(x -> aCadenaEnFichero(x)).collect(Collectors.toSet());

		Ficheros.escribeFichero(objetos, nombreFichero);

	}

	private String aCadenaEnFichero(SerieTV serie) {

		return serie.getNombre() + " (" + serie.getFechaPrimeraEmision().getYear() + ") " + "Temporada: "
				+ serie.getNumeroTemporadas() + " Episodios: " + serie.getNumeroEpisodios();

	}

	/**
	 * @param palabra
	 * 
	 * @return un conjunto ordenado con los nombres de las series en cuya
	 *         sinopsis aparece la palabra dada como par�metro. El conjunto est�
	 *         ordenado alfab�ticamente.
	 * 
	 * @exception sinopsisNula
	 * 
	 */

	public SortedSet<String> getNombresSeriesConPalabraEnSinopsis(String palabra) {
		return getSeriesTV().stream()
				.filter(x -> x.getSinopsis() != null && extraePalabras(x.getSinopsis()).contains(palabra))
				.map(x -> x.getNombre()).collect(Collectors.toCollection(TreeSet::new));
	}

	private List<String> extraePalabras(String s) {
		return Arrays.asList(s.replaceAll("[^A-Za-z�����]+", " ").replaceAll(" +", " ").toLowerCase().split(" "));
	}

	/**
	 * @return un map en el que las claves son las palabras de las sinopsis de
	 *         todas las pel�culas del gestor y el valor asociado a cada clave
	 *         representa el n�mero de veces que se repite la palabra en las
	 *         sinopsis. El conjunto de claves debe estar ordenado
	 *         alfab�ticamente de menor a mayor
	 */

	public SortedMap<String, Long> getFrecuenciaPalabrasSinopsis() {
		// Map<String, List<SerieTV>>
		List<String> palabras = getSeriesTV().stream().filter(x -> x.getSinopsis() != null)
				.flatMap(x -> extraePalabras(x.getSinopsis()).stream()).collect(Collectors.toList());

		Map<String, Long> map = palabras.stream()
				.collect(Collectors.groupingBy((String x) -> x, Collectors.counting()));

		return new TreeMap<String, Long>(map);
	}

	public SerieTV getSerieMasTemporadas() {

		Comparator<SerieTV> cmp = Comparator.comparing((SerieTV x) -> x.getTemporadas().size());

		return getSeriesTV().stream().max(cmp).orElse(null);
	}

	public Integer getNumeroSeriesDeGenero(String genero) {
		// TODO No logro sacarlo
		return getSeriesTV().stream().flatMap(x -> x.getGeneros().stream()).filter(x -> x.getNombre().equals(genero))
				.count();

	}

	public SerieTV getSerieMasEpisodios() {
		Comparator<SerieTV> cmp = Comparator.comparing((SerieTV x) -> x.getEpisodios().size());

		return getSeriesTV().stream().max(cmp).orElse(null);
	}

	public Set<SerieTV> getSeriesDe(MiembroStaff persona) {

		Map<MiembroStaff, Set<SerieTV>> res = new HashMap<>();

	    res.put(persona, getSeriesTV().stream().filter(x -> x.esCreador(persona)).collect(Collectors.toSet()));
	    res.put(persona, getSeriesTV().stream().filter(x -> x.esActor(persona)).collect(Collectors.toSet()));
	    res.put(persona, getSeriesTV().stream().filter(x -> x.esArtistaInvitado(persona)).collect(Collectors.toSet()));

	    return res.get(persona);
	 }

	public Integer[] contarSeriesSegunEstado() {

		Integer[] res = new Integer[EstadoSerie.values().length];

	    Arrays.fill(res, 0);

	    getSeriesTV().stream().forEach(x -> res[x.getEstado().ordinal()]++);

	    return res;

	}

	public Boolean haySeriesDeCadenaTV(String cadenaTV) {
		return getSeriesTV().stream().anyMatch((SerieTV x) -> x.getCadenasTV().contains(cadenaTV));
	}

	public Boolean seEmitieronTodasEn(Integer anyo) {
		 return getSeriesTV().stream()
			        .allMatch(x -> x.getEpisodios().stream().allMatch(y -> anyo.equals(y.getFechaEmision().getYear())));
	}

}
