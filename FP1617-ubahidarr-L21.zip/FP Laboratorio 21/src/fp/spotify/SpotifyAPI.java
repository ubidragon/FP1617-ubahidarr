package fp.spotify;

import java.util.List;

import fp.spotify.pojo.SpotifyAlbumSearch;
import fp.spotify.pojo.SpotifyAlbumSimplified;
import fp.spotify.pojo.SpotifyArtist;
import fp.spotify.pojo.SpotifyArtistSearch;
import fp.spotify.pojo.SpotifyPage;
import fp.spotify.pojo.SpotifyTrack;
import fp.spotify.pojo.SpotifyTrackSearch;

public interface SpotifyAPI {

	SpotifyTrackSearch getTracksByName(String cadenaBusqueda);

	List<SpotifyTrack> getAllTracksByName(String cadenaBusqueda);

	SpotifyArtistSearch getArtistsByName(String cadenaBusqueda);

	List<SpotifyArtist> getAllArtistsByName(String cadenaBusqueda);

	SpotifyAlbumSearch getAlbumsByName(String cadenaBusqueda);

	List<SpotifyAlbumSimplified> getAllAlbumsByName(String cadenaBusqueda);

//	SpotifyPage<SpotifyAlbumSimplified> getAlbumsOfArtist(String idArtista);
//
//	List<SpotifyAlbumSimplified> getAllAlbumsOfArtist(String idArtista);

}