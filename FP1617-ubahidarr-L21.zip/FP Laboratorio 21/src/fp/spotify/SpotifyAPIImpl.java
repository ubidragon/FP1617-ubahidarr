package fp.spotify;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;

import fp.spotify.pojo.SpotifyAlbumSearch;
import fp.spotify.pojo.SpotifyAlbumSimplified;
import fp.spotify.pojo.SpotifyArtist;
import fp.spotify.pojo.SpotifyArtistSearch;
import fp.spotify.pojo.SpotifyArtistSimplified;
import fp.spotify.pojo.SpotifyPage;
import fp.spotify.pojo.SpotifyTrack;
import fp.spotify.pojo.SpotifyTrackSearch;
import fp.utiles.UtilesJSon;

public class SpotifyAPIImpl implements SpotifyAPI {

	// 1: Definir los endpoints necesarios para usar el recurso que realiza
	// las búsquedas en Spotify
	// (https://developer.spotify.com/web-api/search-item/)
	private static final String URL_BASE = "https://api.spotify.com/v1";
	private static final String URL_SEARCH = URL_BASE + "/search";

	// 1.2: Definir el conjunto de parámetros para la búsqueda de acuerdo
	// con la documentación del API de Spotify
	private static final String[] SEARCH_PARAMS = { "q", "type", "limit" };
	private static final Integer RESULTADOS_POR_PAGINA = 50; // Es el m�ximo
																// permitido
	private static String TRACK_TYPE = "track";
	private static String ARTIST_TYPE = "artist";
	private static String ALBUM_TYPE = "album";
	
	

	// 2: Definir el método getTracksByName usando el tipo
	// SpotifyTrackSearch
	public SpotifyTrackSearch getTracksByName(String busqueda) {

		String[] values = { busqueda, TRACK_TYPE, RESULTADOS_POR_PAGINA.toString() };
		return UtilesJSon.fromJSON_URL(URL_SEARCH, SEARCH_PARAMS, values, SpotifyTrackSearch.class);
	}

	// 3: Definir un método privado para, a partir de un objeto tipo
	// SpotifyTrackSearch , obtener la siguiente página.
	private SpotifyTrackSearch getNextSearchPage(SpotifyTrackSearch currentSearch) {
		SpotifyTrackSearch res = null;

		if (currentSearch != null && currentSearch.getTracks() != null && currentSearch.getTracks().getNext() != null) {
			res = UtilesJSon.fromJSON_URL(currentSearch.getTracks().getNext(), SpotifyTrackSearch.class);

		}

		return res;
	}
	// TODO 4: Defina el método getAllTracksByName usando los métodos
	// anteriores. Recuerde, que es posible que recibamos objetos de búsqueda
	// nulos o con propiedades nulas.

	public List<SpotifyTrack> getAllTracksByName(String cadenaBusqueda) {
		List<SpotifyTrack> res = new ArrayList<>();
		SpotifyTrackSearch current = getTracksByName(cadenaBusqueda);
		while (current != null) {

			SpotifyPage<SpotifyTrack> page = current.getTracks();
			if (page != null) {
				List<SpotifyTrack> tracks = page.getItems();
				res.addAll(tracks);
			}

			current = getNextSearchPage(current);
		}
		return res;
	}

	@Override
	public SpotifyArtistSearch getArtistsByName(String busqueda) {
		String[] values = { busqueda, ARTIST_TYPE, RESULTADOS_POR_PAGINA.toString() };
		return UtilesJSon.fromJSON_URL(URL_SEARCH, SEARCH_PARAMS, values, SpotifyArtistSearch.class);
	}

	private SpotifyArtistSearch getNextSearchPage(SpotifyArtistSearch currentSearch) {
		SpotifyArtistSearch result = null;
		String url = currentSearch.getArtists().getNext();
		if (url != null) {
			result = UtilesJSon.fromJSON_URL(url, new TypeReference<SpotifyArtistSearch>() {
			});
		}
		return result;
	}

	@Override
	public List<SpotifyArtist> getAllArtistsByName(String cadenaBusqueda) {
		List<SpotifyArtist> result = new ArrayList<SpotifyArtist>();

		SpotifyArtistSearch search = getArtistsByName(cadenaBusqueda);
		while (search != null) {
			SpotifyPage<SpotifyArtist> page = search.getArtists();
			if (page != null) {
				result.addAll(page.getItems());
				search = getNextSearchPage(search);
			}

		}

		return result;
	}

	@Override
	public SpotifyAlbumSearch getAlbumsByName(String busqueda) {
		String[] values = { busqueda, ALBUM_TYPE, RESULTADOS_POR_PAGINA.toString() };
		return UtilesJSon.fromJSON_URL(URL_SEARCH, SEARCH_PARAMS, values, SpotifyAlbumSearch.class);
	}

	private SpotifyAlbumSearch getNextSearchPage(SpotifyAlbumSearch currentSearch) {
		SpotifyAlbumSearch result = null;
		String url = currentSearch.getAlbums().getNext();
		if (url != null) {
			result = UtilesJSon.fromJSON_URL(url, new TypeReference<SpotifyAlbumSearch>() {
			});
		}
		return result;
	}
	
	@Override
	public List<SpotifyAlbumSimplified> getAllAlbumsByName(String cadenaBusqueda) {
		List<SpotifyAlbumSimplified> result = new ArrayList<SpotifyAlbumSimplified>();

		SpotifyAlbumSearch search = getAlbumsByName(cadenaBusqueda);
		while (search != null) {
			SpotifyPage<SpotifyAlbumSimplified> page = search.getAlbums();
			if (page != null) {
				result.addAll(page.getItems());
				search = getNextSearchPage(search);
			}

		}

		return result;
	}

// TODO: no es necesario
//	@Override
//	public SpotifyPage<SpotifyAlbumSimplified> getAlbumsOfArtist(String idArtista) {
//		String[] values = { idArtista ,ALBUM_TYPE, RESULTADOS_POR_PAGINA.toString() };
//		
//		return UtilesJSon.fromJSON_URL(URL_SEARCH, SEARCH_PARAMS, values, SpotifyPage.class);
//	}
//
//	@Override
//	public List<SpotifyAlbumSimplified> getAllAlbumsOfArtist(String idArtista) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
