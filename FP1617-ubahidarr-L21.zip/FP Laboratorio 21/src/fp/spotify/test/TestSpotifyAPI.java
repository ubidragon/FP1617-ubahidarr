package fp.spotify.test;

import java.util.List;

import fp.spotify.SpotifyAPI;
import fp.spotify.SpotifyAPIImpl;
import fp.spotify.pojo.SpotifyAlbumSearch;
import fp.spotify.pojo.SpotifyAlbumSimplified;
import fp.spotify.pojo.SpotifyArtist;
import fp.spotify.pojo.SpotifyArtistSearch;
import fp.spotify.pojo.SpotifyPage;
import fp.spotify.pojo.SpotifyTrack;
import fp.spotify.pojo.SpotifyTrackSearch;

public class TestSpotifyAPI {

	public static void main(String[] args) {
		SpotifyAPI api = new SpotifyAPIImpl();

		testGetTracksByName(api, "La bicicleta");
		testGetTracksByName(api, "Slow Wine");

		testGetAllTracksByName(api, "La bicicleta");
		testGetAllTracksByName(api, "Slow Wine");

		testGetArtista(api, "Tania Bowra");
		testGetArtista(api, "Radiohead");

		testGetAllArtistByName(api, "La bicicleta");
		testGetAllArtistByName(api, "Slow Wine");

		testGetAlbumsByName(api, "Thriller");
		testGetAlbumsByName(api, "Private dancer");

		testGetAllAlbumsByName(api, "Thriller");
		testGetAllAlbumsByName(api, "Private dancer");

//		 testGetAlbumsOfArtist(api, "0OdUWJ0sBjDrqHygGUXeCF");
		// testGetAllAlbumsOfArtist(api, "0OdUW4J0sBjDrqHygGUXeCF");
		
		
		 

	}

	private static void testGetTracksByName(SpotifyAPI api, String cancion) {
		System.out.println("Solicitando la canción con nombre " + cancion);
		SpotifyTrackSearch track = api.getTracksByName(cancion);
		System.out.println(track);
		System.out.println("================================================\n\n");
	}

	private static void testGetAllTracksByName(SpotifyAPI api, String cancion) {
		System.out.println("Solicitando las canciones con nombre " + cancion);
		List<SpotifyTrack> tracks = api.getAllTracksByName(cancion);
		tracks.forEach(x -> System.out.println(x));
		System.out.println("================================================\n\n");
	}

	private static void testGetArtista(SpotifyAPI api, String artista) {
		System.out.println("Solicitando el artista " + artista);
		SpotifyArtistSearch artist = api.getArtistsByName(artista);
		System.out.println(artist);
		System.out.println("================================================\n\n");
	}

	private static void testGetAllArtistByName(SpotifyAPI api, String artista) {
		System.out.println("Solicitando los artistas " + artista);
		List<SpotifyArtist> artistas = api.getAllArtistsByName(artista);
		artistas.forEach(x -> System.out.println(x));
		System.out.println("================================================\n\n");
	}

	private static void testGetAlbumsByName(SpotifyAPI api, String album) {
		System.out.println("Solicitando el album con nombre " + album);
		SpotifyAlbumSearch albums = api.getAlbumsByName(album);
		System.out.println(albums);
		System.out.println("================================================\n\n");
	}

	private static void testGetAllAlbumsByName(SpotifyAPI api, String album) {
		System.out.println("Solicitando los albums con nombre " + album);
		List<SpotifyAlbumSimplified> albums = api.getAllAlbumsByName(album);
		albums.forEach(x -> System.out.println(x));
		System.out.println("================================================\n\n");
	}

//	private static void testGetAlbumsOfArtist(SpotifyAPI api, String id) {
//
//		System.out.println("Solicitando el/los albums de " + id);
//		SpotifyPage<SpotifyAlbumSimplified> albums = api.getAlbumsOfArtist(id);
//		System.out.println(albums);
//		System.out.println("================================================\n\n");
//	}
//
//	private static void testGetAllAlbumsOfArtist(SpotifyAPI api, String id) {
//		System.out.println("Solicitando los albums con nombre " + id);
//		List<SpotifyAlbumSimplified> albums = api.getAllAlbumsOfArtist(id);
//		albums.forEach(x -> System.out.println(x));
//		System.out.println("================================================\n\n");
//	}

}
