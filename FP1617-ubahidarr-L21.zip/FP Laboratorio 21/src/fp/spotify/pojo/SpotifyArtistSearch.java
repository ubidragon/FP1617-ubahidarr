package fp.spotify.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class SpotifyArtistSearch {
	
	private SpotifyPage<SpotifyArtist> artists;

	public SpotifyArtistSearch() {
		super();
	}

	public SpotifyPage<SpotifyArtist> getArtists() {
		return artists;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((artists == null) ? 0 : artists.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SpotifyArtistSearch other = (SpotifyArtistSearch) obj;
		if (artists == null) {
			if (other.artists != null)
				return false;
		} else if (!artists.equals(other.artists))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SpotifyArtistSearch [artists=" + artists + "]";
	}
	
	

}
