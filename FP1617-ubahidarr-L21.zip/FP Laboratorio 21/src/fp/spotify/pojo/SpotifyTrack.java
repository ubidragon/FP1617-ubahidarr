package fp.spotify.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class SpotifyTrack{

	private String id;
	private String name;
	private Integer popularity;
	@JsonProperty("preview_url")
	private String previewUrl;
	
	public SpotifyTrack() {
		super();
	}
	
	
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public Integer getPopularity() {
		return popularity;
	}
	public String getPreviewUrl() {
		return previewUrl;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((popularity == null) ? 0 : popularity.hashCode());
		result = prime * result + ((previewUrl == null) ? 0 : previewUrl.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SpotifyTrack other = (SpotifyTrack) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (popularity == null) {
			if (other.popularity != null)
				return false;
		} else if (!popularity.equals(other.popularity))
			return false;
		if (previewUrl == null) {
			if (other.previewUrl != null)
				return false;
		} else if (!previewUrl.equals(other.previewUrl))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "SpotifyTrack [id=" + id + ", name=" + name + ", popularity=" + popularity + ", previewUrl=" + previewUrl
				+ "]";
	}
	
	

}
