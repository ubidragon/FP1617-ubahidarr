package fp.audiovisuales;

public enum TipoMetraje {
	CORTOMETRAJE, MEDIOMETRAJE, LARGOMETRAJE
}
