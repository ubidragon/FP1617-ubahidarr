package fp.musica;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import fp.utiles.Imagenes;

public class ListaReproduccionImpl2 extends ListaReproduccionImpl {

	public ListaReproduccionImpl2(String nombre) {
		super(nombre);
	}

	/** Redefinicion de metodos de tratamientos secuenciales **/

	public Set<Artista> getArtistas() {
		return getCanciones().stream().flatMap(x -> x.getArtistas().stream()).collect(Collectors.toSet());

		/*
		 * Set<Artista> result = new HashSet<Artista>();
		 * getCanciones().stream().map(Cancion::getArtistas).forEach(x ->
		 * result.addAll(x)); return result;
		 */
	}

	public void muestraFotoArtista() {
		Comparator<Artista> cmp = Comparator.comparing(x -> x.getNombre());
		getArtistas().stream().filter(x -> x.getURLImagenes().isEmpty()).sorted(cmp)
				.forEach((Artista x) -> Imagenes.show(x.getNombre(), x.getURLImagenes().get(0)));

	}

	public Map<String, List<Cancion>> getCancionesPorArtista() {

		return getCanciones().stream()
				.collect(Collectors.groupingBy((Cancion x) -> x.getArtistas().get(0).getNombre()));

	}

	public Map<String, Long> getNumeroCancionesPorArtista() {

		return getCanciones().stream().collect(
				Collectors.groupingBy((Cancion x) -> x.getArtistas().get(0).getNombre(), Collectors.counting()));

	}

	public Map<String, Integer> getDuracionTotalPorArtista() {
		return getCanciones().stream().filter(c -> c.getArtistas().size() == 1)
				.collect(Collectors.groupingBy((Cancion x) -> x.getArtistas().get(0).getNombre(),
						Collectors.summingInt((Cancion c) -> (int) c.getDuracion().getSeconds())));

		/**
		 * List<Cancion> lista new ArrayList<>();
		 * Integer duracion = lista.stream().collect(Collectors.summingInt(x -> (int) x.getDuracion().getSeconds())
		 * 
		 * return getCanciones().stream()
		 * 
		 */
		
		
	}
	
	/* TODO
	 * - GestorPeliculasFavoritasImpl2 :: getActorMasPeliculas
	 * 	MiembroStaff getActorMasPeliculas(): Proporciona el actor que ha participado en m�s
	 *  pel�culas entre las favoritas del gestor. Si no hay pel�culas devuelve null.
	 *  
	 *  
	 * - GestorPeliculasFavoritasImpl2 :: getGeneros
	 * 	Set<String> getGeneros(): Proporciona el conjunto de g�neros de todas
	 *  las pel�culas del gestor. Si no hay pel�culas devuelve el conjunto vac�o.
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getPeliculasPorDirector
	 * 	Map<String, Set<Pelicula>> getPeliculasPorDirector(). Devuelve un Map que relaciona
	 *  los nombres de los directores con el conjunto de pel�culas dirigidas en solitario 
	 *  por dichos directores (es decir, no se incluyen las pel�culas codirigidas por varios
	 *  directores).
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getDuracionMediaPorDirector
	 * 	Map<String, Double>> getDuracionMediaPorDirector(). Devuelve un Map que relaciona los
	 *  nombres de los directores con la duraci�n media en minutos de las pel�culas dirigidas
	 *  en solitario por dichos directores (es decir, no se incluyen las pel�culas codirigidas
	 *  por varios directores).
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getPaises
	 * 	Set<String> getPaises(): Proporciona el conjunto de pa�ses de todas
	 *  las pel�culas del gestor. Si no hay pel�culas devuelve el conjunto vac�o.
	 * 
	 * 
	 * - ListaReproduccionImpl2 :: esAntologia 
	 * 	Boolean esAntologia(String artista). Devuelve true si todas 
	 *	las canciones de la lista de reproducci�n son del artista especificado.
	 * 
	 */

}
