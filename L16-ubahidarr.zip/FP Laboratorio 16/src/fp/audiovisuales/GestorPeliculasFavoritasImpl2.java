package fp.audiovisuales;

import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import fp.musica.Artista;
import fp.musica.Cancion;

public class GestorPeliculasFavoritasImpl2 extends GestorPeliculasFavoritasImpl {

	public GestorPeliculasFavoritasImpl2(String id, String nombre, Set<Pelicula> peliculas) {
		super(id, nombre, peliculas);
	}

	public GestorPeliculasFavoritasImpl2(String id, String nombre) {
		super(id, nombre);
	}

	/*
	 * TODO - GestorPeliculasFavoritasImpl2 :: getActorMasPeliculas MiembroStaff
	 * getActorMasPeliculas(): Proporciona el actor que ha participado en m�s
	 * pel�culas entre las favoritas del gestor. Si no hay pel�culas devuelve
	 * null.
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getGeneros Set<String> getGeneros():
	 * Proporciona el conjunto de g�neros de todas las pel�culas del gestor. Si
	 * no hay pel�culas devuelve el conjunto vac�o.
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getPeliculasPorDirector Map<String,
	 * Set<Pelicula>> getPeliculasPorDirector(). Devuelve un Map que relaciona
	 * los nombres de los directores con el conjunto de pel�culas dirigidas en
	 * solitario por dichos directores (es decir, no se incluyen las pel�culas
	 * codirigidas por varios directores).
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getDuracionMediaPorDirector
	 * Map<String, Double>> getDuracionMediaPorDirector(). Devuelve un Map que
	 * relaciona los nombres de los directores con la duraci�n media en minutos
	 * de las pel�culas dirigidas en solitario por dichos directores (es decir,
	 * no se incluyen las pel�culas codirigidas por varios directores).
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getPaises Set<String> getPaises():
	 * Proporciona el conjunto de pa�ses de todas las pel�culas del gestor. Si
	 * no hay pel�culas devuelve el conjunto vac�o.
	 */

	public Set<MiembroStaff> getActores() {
		return getPeliculas().stream().flatMap(x -> x.getActores().stream()).collect(Collectors.toSet());

	}

	/**
	 * @return el conjunto de pa�ses de todas las pel�culas del gestor. Si no
	 *         hay pel�culas devuelve el conjunto vac�o.
	 */

	public Set<String> getPaises() {

		return getPeliculas().stream().flatMap(x -> x.getPaises().stream()).collect(Collectors.toSet());

	}

	/**
	 * @return Proporciona el conjunto de g�neros de todas las pel�culas del
	 *         gestor. Si no hay pel�culas devuelve el conjunto vac�o.
	 **/

	public Set<String> getGeneros() {

		return getPeliculas().stream().flatMap(x -> x.getGeneros().stream()).collect(Collectors.toSet());

	}

	/**
	 * @return Proporciona el actor que ha participado en m�s pel�culas entre
	 *         las favoritas del gestor. Si no hay pel�culas devuelve null.
	 **/

	public MiembroStaff getActorMasPeliculas() {
		 //TODO No logro sacarlo
		Comparator<GestorPeliculasFavoritas> cmp = Comparator.comparingInt(x -> x.getPeliculas().size());

		return getActores().stream().collect(Collectors.maxBy(cmp));

	}

	/**
	 * @return Devuelve un Map que relaciona los nombres de los directores con
	 *         el conjunto de pel�culas dirigidas en solitario por dichos
	 *         directores (es decir, no se incluyen las pel�culas codirigidas
	 *         por varios directores).
	 **/

	public Map<String, Set<Pelicula>> getPeliculasPorDirector() {
		 //TODO No logro sacarlo
		return getPeliculas().stream()
				.collect(Collectors.groupingBy((MiembroStaff x) -> x.getDirectores().get(0).getNombre(),
						Collectors.groupingBy(GestorPeliculasFavoritas::getPeliculas)));

	}

	 /**
	 * @return Devuelve un Map que relaciona los nombres de los directores con
	 * la duraci�n media en minutos de las pel�culas dirigidas en
	 * solitario por dichos directores (es decir, no se incluyen las
	 * pel�culas codirigidas por varios directores).
	 **/
	
	 public Map<String, Double> getDuracionMediaPorDirector() {
		 //TODO No logro sacarlo
		 return getPeliculas().stream().collect();
	
	 }

}
