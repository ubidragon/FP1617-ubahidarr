package fp.musica;

public enum TipoAlbum {
	ALBUM, SINGLE, COMPILATION;
}
