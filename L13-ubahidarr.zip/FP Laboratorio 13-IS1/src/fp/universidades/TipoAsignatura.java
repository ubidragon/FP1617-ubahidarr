package fp.universidades;

public enum TipoAsignatura {
	ANUAL, PRIMER_CUATRIMESTRE, SEGUNDO_CUATRIMESTRE
}
