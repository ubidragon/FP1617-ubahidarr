package fp.tmdb;

import fp.tmdb.pojo.TMDBMovie;
import fp.tmdb.pojo.TMDBNetwork;
import fp.tmdb.pojo.TMDBPerson;
import fp.tmdb.pojo.TMDBReview;
import fp.tmdb.pojo.TMDBTVEpisode;
import fp.tmdb.pojo.TMDBTVSerie;
import fp.utiles.Propiedades;
import fp.utiles.UtilesJSon;

public class TMDBAPIImpl implements TMDBAPI {

	// TODO 1: Definir constantes y métodos para controlar el acceso a la clave
	// de la api.
	private static final String FICHERO_PROPIEDADES = "config.properties";
	private static final String PROPIEDAD_APIKEY = "apikey";
	private String apiKey;

	private String obtainAPIKey() {
		return Propiedades.getProperty(FICHERO_PROPIEDADES, PROPIEDAD_APIKEY);
	}

	public TMDBAPIImpl() {
		apiKey = obtainAPIKey();
	}

	// 2: Definir URLs para el acceso a los recursos del servicio
	private static final String URL_BASE = "https://api.themoviedb.org/3/";
	private static final String URL_NETWORK = URL_BASE + "network/";
	private static final String URL_PEOPLE = URL_BASE + "person/";
	private static final String URL_MOVIE = URL_BASE + "movie/";
	private static final String URL_TVSERIES = URL_BASE + "tv/";
//	private static final String URL_TVSEASON = URL_TVSERIES + "season/";
//	private static final String URL_TVEPISODE = URL_TVSEASON + "episode/";
	private static final String URL_REVIEW = URL_BASE + "review/";

	private String getKeyParameter() {
		return "?api_key=" + apiKey;
	}

	// TODO 3: Completar los métodos pendientes usando los tipos proporcionados.

	public TMDBPerson getPerson(Integer idPersona) {
		String url = URL_PEOPLE + idPersona + getKeyParameter();
		return UtilesJSon.fromJSON_URL(url, TMDBPerson.class);
	}

	public TMDBNetwork getNetwork(Integer idCadena) {
		String url = URL_NETWORK + idCadena + getKeyParameter();
		return UtilesJSon.fromJSON_URL(url, TMDBNetwork.class);
	}

	// TODO 4: Definir los tipos TMDBNamedObject y TMDBMovie y completar el
	// resto de métodos.
	public TMDBMovie getMovie(Integer idMovie) {
		String url = URL_MOVIE + idMovie + getKeyParameter();
		return UtilesJSon.fromJSON_URL(url, TMDBMovie.class);
	}

	public TMDBTVSerie getTVSerie(Integer tv) {

		String url = URL_TVSERIES + tv + getKeyParameter();
		return UtilesJSon.fromJSON_URL(url, TMDBTVSerie.class);
	}

	@Override
	public TMDBTVEpisode getTVEpisode(Integer idTVSerie, Integer seasonNumber, Integer episodeNumber) {
		String url = URL_TVSERIES + idTVSerie + "/season/" + seasonNumber+ "/episode/"+ episodeNumber+getKeyParameter();
		return UtilesJSon.fromJSON_URL(url, TMDBTVEpisode.class);
	}

	@Override
	public TMDBReview getReview(String id) {
		String url = URL_REVIEW + id + getKeyParameter();
		return UtilesJSon.fromJSON_URL(url, TMDBReview.class);
	}

}
