/**
 * 
 */
package fp.tmdb.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ubidragon
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TMDBReview {

	private String id;
	private String author;
	private String content;
	@JsonProperty("media_title")
	private String mediaTitle;
	@JsonProperty("media_type")
	private String mediaType;
	private String url;

	public TMDBReview() {

	}

	public String getId() {
		return id;
	}

	public String getAuthor() {
		return author;
	}

	public String getContent() {
		return content;
	}

	public String getMediaTitle() {
		return mediaTitle;
	}

	public String getMediaType() {
		return mediaType;
	}

	public String getUrl() {
		return url;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		result = prime * result + ((content == null) ? 0 : content.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((mediaTitle == null) ? 0 : mediaTitle.hashCode());
		result = prime * result + ((mediaType == null) ? 0 : mediaType.hashCode());
		result = prime * result + ((url == null) ? 0 : url.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TMDBReview other = (TMDBReview) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		if (content == null) {
			if (other.content != null)
				return false;
		} else if (!content.equals(other.content))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (mediaTitle == null) {
			if (other.mediaTitle != null)
				return false;
		} else if (!mediaTitle.equals(other.mediaTitle))
			return false;
		if (mediaType == null) {
			if (other.mediaType != null)
				return false;
		} else if (!mediaType.equals(other.mediaType))
			return false;
		if (url == null) {
			if (other.url != null)
				return false;
		} else if (!url.equals(other.url))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TMDBReview [id=" + id + ", author=" + author + ", content=" + content + ", mediaTitle=" + mediaTitle
				+ ", mediaType=" + mediaType + ", url=" + url + "]";
	}

}
