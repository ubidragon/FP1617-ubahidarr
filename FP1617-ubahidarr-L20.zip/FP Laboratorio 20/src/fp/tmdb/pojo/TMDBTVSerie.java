package fp.tmdb.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TMDBTVSerie {

	private Integer id;
	private String name;
	@JsonProperty("created_by")
	private List<TMDBPerson> createdBy;
	@JsonProperty("first_air_date")
	private String firstAirDate;
	@JsonProperty("episode_run_time")
	private List<Integer> episodeRuntime;
	private List<TMDBNamedObject> genres;
	private String homepage;
	@JsonProperty("last_air_date")
	private String lastAirDate;
	private List<TMDBNamedObject> networks;
	@JsonProperty("original_name")
	private String originalName;
	@JsonProperty("original_language")
	private String originalLanguage;
	private Double popularity;
	@JsonProperty("production_companies")
	private List<TMDBNamedObject> productionCompanies;
	private List<TMDBTVSeasonShort> seasons;
	private String status;
	private String type;
	@JsonProperty("vote_average")
	private Double voteAverage;
	@JsonProperty("vote_count")
	private Integer voteCount;
	@JsonProperty("number_of_episodes")
	private Integer numberOfEpisodes;
	@JsonProperty("number_of_seasons")
	private Integer numberOfSeasons;
	private String overview;
	@JsonProperty("origin_country")
	private List<String> originCountry;

	public TMDBTVSerie() {

	}

	public Integer getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public List<TMDBPerson> getCreatedBy() {
		return createdBy;
	}

	public String getFirstAirDate() {
		return firstAirDate;
	}

	public List<Integer> getEpisodeRuntime() {
		return episodeRuntime;
	}

	public List<TMDBNamedObject> getGenres() {
		return genres;
	}

	public String getHomepage() {
		return homepage;
	}

	public String getLastAirDate() {
		return lastAirDate;
	}

	public List<TMDBNamedObject> getNetworks() {
		return networks;
	}

	public String getOriginalName() {
		return originalName;
	}

	public String getOriginalLanguage() {
		return originalLanguage;
	}

	public Double getPopularity() {
		return popularity;
	}

	public List<TMDBNamedObject> getProductionCompanies() {
		return productionCompanies;
	}

	public List<TMDBTVSeasonShort> getSeasons() {
		return seasons;
	}

	public String getStatus() {
		return status;
	}

	public String getType() {
		return type;
	}

	public Double getVoteAverage() {
		return voteAverage;
	}

	public Integer getVoteCount() {
		return voteCount;
	}

	public Integer getNumberOfEpisodes() {
		return numberOfEpisodes;
	}

	public Integer getNumberOfSeasons() {
		return numberOfSeasons;
	}

	public String getOverview() {
		return overview;
	}

	public List<String> getOriginCountry() {
		return originCountry;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((episodeRuntime == null) ? 0 : episodeRuntime.hashCode());
		result = prime * result + ((firstAirDate == null) ? 0 : firstAirDate.hashCode());
		result = prime * result + ((genres == null) ? 0 : genres.hashCode());
		result = prime * result + ((homepage == null) ? 0 : homepage.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastAirDate == null) ? 0 : lastAirDate.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((networks == null) ? 0 : networks.hashCode());
		result = prime * result + ((numberOfEpisodes == null) ? 0 : numberOfEpisodes.hashCode());
		result = prime * result + ((numberOfSeasons == null) ? 0 : numberOfSeasons.hashCode());
		result = prime * result + ((originCountry == null) ? 0 : originCountry.hashCode());
		result = prime * result + ((originalLanguage == null) ? 0 : originalLanguage.hashCode());
		result = prime * result + ((originalName == null) ? 0 : originalName.hashCode());
		result = prime * result + ((overview == null) ? 0 : overview.hashCode());
		result = prime * result + ((popularity == null) ? 0 : popularity.hashCode());
		result = prime * result + ((productionCompanies == null) ? 0 : productionCompanies.hashCode());
		result = prime * result + ((seasons == null) ? 0 : seasons.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((voteAverage == null) ? 0 : voteAverage.hashCode());
		result = prime * result + ((voteCount == null) ? 0 : voteCount.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TMDBTVSerie other = (TMDBTVSerie) obj;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (episodeRuntime == null) {
			if (other.episodeRuntime != null)
				return false;
		} else if (!episodeRuntime.equals(other.episodeRuntime))
			return false;
		if (firstAirDate == null) {
			if (other.firstAirDate != null)
				return false;
		} else if (!firstAirDate.equals(other.firstAirDate))
			return false;
		if (genres == null) {
			if (other.genres != null)
				return false;
		} else if (!genres.equals(other.genres))
			return false;
		if (homepage == null) {
			if (other.homepage != null)
				return false;
		} else if (!homepage.equals(other.homepage))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastAirDate == null) {
			if (other.lastAirDate != null)
				return false;
		} else if (!lastAirDate.equals(other.lastAirDate))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (networks == null) {
			if (other.networks != null)
				return false;
		} else if (!networks.equals(other.networks))
			return false;
		if (numberOfEpisodes == null) {
			if (other.numberOfEpisodes != null)
				return false;
		} else if (!numberOfEpisodes.equals(other.numberOfEpisodes))
			return false;
		if (numberOfSeasons == null) {
			if (other.numberOfSeasons != null)
				return false;
		} else if (!numberOfSeasons.equals(other.numberOfSeasons))
			return false;
		if (originCountry == null) {
			if (other.originCountry != null)
				return false;
		} else if (!originCountry.equals(other.originCountry))
			return false;
		if (originalLanguage == null) {
			if (other.originalLanguage != null)
				return false;
		} else if (!originalLanguage.equals(other.originalLanguage))
			return false;
		if (originalName == null) {
			if (other.originalName != null)
				return false;
		} else if (!originalName.equals(other.originalName))
			return false;
		if (overview == null) {
			if (other.overview != null)
				return false;
		} else if (!overview.equals(other.overview))
			return false;
		if (popularity == null) {
			if (other.popularity != null)
				return false;
		} else if (!popularity.equals(other.popularity))
			return false;
		if (productionCompanies == null) {
			if (other.productionCompanies != null)
				return false;
		} else if (!productionCompanies.equals(other.productionCompanies))
			return false;
		if (seasons == null) {
			if (other.seasons != null)
				return false;
		} else if (!seasons.equals(other.seasons))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (voteAverage == null) {
			if (other.voteAverage != null)
				return false;
		} else if (!voteAverage.equals(other.voteAverage))
			return false;
		if (voteCount == null) {
			if (other.voteCount != null)
				return false;
		} else if (!voteCount.equals(other.voteCount))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TMDBTVSerie [id=" + id + ", name=" + name + ", createdBy=" + createdBy + ", firstAirDate="
				+ firstAirDate + ", episodeRuntime=" + episodeRuntime + ", genres=" + genres + ", homepage=" + homepage
				+ ", lastAirDate=" + lastAirDate + ", networks=" + networks + ", originalName=" + originalName
				+ ", originalLanguage=" + originalLanguage + ", popularity=" + popularity + ", productionCompanies="
				+ productionCompanies + ", seasons=" + seasons + ", status=" + status + ", type=" + type
				+ ", voteAverage=" + voteAverage + ", voteCount=" + voteCount + ", numberOfEpisodes=" + numberOfEpisodes
				+ ", numberOfSeasons=" + numberOfSeasons + ", overview=" + overview + ", originCountry=" + originCountry
				+ "]";
	}

	

}
