package fp.tmdb.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TMDBMovie {
	// TODO 4.2
	@JsonProperty("original_title")
	private String originalTitle;
	@JsonProperty("overview")
	private String overView;
	private Integer budget;
	private List<TMDBNamedObject> genres;
	@JsonProperty("production_countries")
	private List<TMDBCountry> productionCountries;

	public TMDBMovie() {

	}

	public String getOriginalTitle() {
		return originalTitle;
	}

	public String getOverView() {
		return overView;
	}

	public Integer getBudget() {
		return budget;
	}

	public List<TMDBNamedObject> getGenres() {
		return genres;
	}

	public List<TMDBCountry> getProductionCountries() {
		return productionCountries;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((originalTitle == null) ? 0 : originalTitle.hashCode());
		result = prime * result + ((overView == null) ? 0 : overView.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TMDBMovie other = (TMDBMovie) obj;
		if (originalTitle == null) {
			if (other.originalTitle != null)
				return false;
		} else if (!originalTitle.equals(other.originalTitle))
			return false;
		if (overView == null) {
			if (other.overView != null)
				return false;
		} else if (!overView.equals(other.overView))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TMDBMovie [originalTitle=" + originalTitle + ", overView=" + overView + ", budget=" + budget
				+ ", genres=" + genres + ", productionCountries=" + productionCountries + "]";
	}

}