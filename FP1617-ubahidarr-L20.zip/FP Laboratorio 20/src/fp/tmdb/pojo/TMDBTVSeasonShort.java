package fp.tmdb.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class TMDBTVSeasonShort {
	
	private Integer id;
	@JsonProperty("season_number")
	private Integer seasonNumber;
	@JsonProperty("episode_count")
	private Integer episodeCounting;
	@JsonProperty("air_date")
	private String airDate;
	
	
	public TMDBTVSeasonShort(){
		
	}


	public Integer getId() {
		return id;
	}


	public Integer getSeasonNumber() {
		return seasonNumber;
	}


	public Integer getEpisodeCounting() {
		return episodeCounting;
	}


	public String getAirDate() {
		return airDate;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((airDate == null) ? 0 : airDate.hashCode());
		result = prime * result + ((episodeCounting == null) ? 0 : episodeCounting.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((seasonNumber == null) ? 0 : seasonNumber.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TMDBTVSeasonShort other = (TMDBTVSeasonShort) obj;
		if (airDate == null) {
			if (other.airDate != null)
				return false;
		} else if (!airDate.equals(other.airDate))
			return false;
		if (episodeCounting == null) {
			if (other.episodeCounting != null)
				return false;
		} else if (!episodeCounting.equals(other.episodeCounting))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (seasonNumber == null) {
			if (other.seasonNumber != null)
				return false;
		} else if (!seasonNumber.equals(other.seasonNumber))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "TMDBTVSeasonShort [id=" + id + ", seasonNumber=" + seasonNumber + ", episodeCounting=" + episodeCounting
				+ ", airDate=" + airDate + "]";
	}

}
