package fp.audiovisuales;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class GestorPeliculasFavoritasImpl2 extends GestorPeliculasFavoritasImpl {

	public GestorPeliculasFavoritasImpl2(String id, String nombre, Set<Pelicula> peliculas) {
		super(id, nombre, peliculas);
	}

	public GestorPeliculasFavoritasImpl2(String id, String nombre) {
		super(id, nombre);
	}

	/*
	 * GestorPeliculasFavoritasImpl2 :: getActorMasPeliculas MiembroStaff
	 * getActorMasPeliculas(): Proporciona el actor que ha participado en m�s
	 * pel�culas entre las favoritas del gestor. Si no hay pel�culas devuelve
	 * null.
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getGeneros Set<String> getGeneros():
	 * Proporciona el conjunto de g�neros de todas las pel�culas del gestor. Si
	 * no hay pel�culas devuelve el conjunto vac�o.
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getPeliculasPorDirector Map<String,
	 * Set<Pelicula>> getPeliculasPorDirector(). Devuelve un Map que relaciona
	 * los nombres de los directores con el conjunto de pel�culas dirigidas en
	 * solitario por dichos directores (es decir, no se incluyen las pel�culas
	 * codirigidas por varios directores).
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getDuracionMediaPorDirector
	 * Map<String, Double>> getDuracionMediaPorDirector(). Devuelve un Map que
	 * relaciona los nombres de los directores con la duraci�n media en minutos
	 * de las pel�culas dirigidas en solitario por dichos directores (es decir,
	 * no se incluyen las pel�culas codirigidas por varios directores).
	 * 
	 * 
	 * - GestorPeliculasFavoritasImpl2 :: getPaises Set<String> getPaises():
	 * Proporciona el conjunto de pa�ses de todas las pel�culas del gestor. Si
	 * no hay pel�culas devuelve el conjunto vac�o.
	 */

	// No es necesario este auxiliar
	// public Set<MiembroStaff> getActores() {
	// return getPeliculas().stream().flatMap(x ->
	// x.getActores().stream()).collect(Collectors.toSet());
	//
	// }

	/**
	 * @return el conjunto de pa�ses de todas las pel�culas del gestor. Si no
	 *         hay pel�culas devuelve el conjunto vac�o.
	 */

	public Set<String> getPaises() {

		return getPeliculas().stream().flatMap(x -> x.getPaises().stream()).collect(Collectors.toSet());

	}

	/**
	 * @return Proporciona el conjunto de g�neros de todas las pel�culas del
	 *         gestor. Si no hay pel�culas devuelve el conjunto vac�o.
	 **/

	public Set<String> getGeneros() {

		return getPeliculas().stream().flatMap(x -> x.getGeneros().stream()).collect(Collectors.toSet());

	}

	/**
	 * @return Proporciona el actor que ha participado en m�s pel�culas entre
	 *         las favoritas del gestor. Si no hay pel�culas devuelve null.
	 **/

	public MiembroStaff getActorMasPeliculas() {

		return getPeliculas().stream().flatMap(x -> x.getActores().stream()).distinct()
				.max(Comparator.comparing(x -> cuentaPeliculas(x.getNombre()))).orElse(null);

	}

	/**
	 * @return Devuelve un Map que relaciona los nombres de los directores con
	 *         el conjunto de pel�culas dirigidas en solitario por dichos
	 *         directores (es decir, no se incluyen las pel�culas codirigidas
	 *         por varios directores).
	 **/

	public Map<String, Set<Pelicula>> getPeliculasPorDirector() {

		// return getPeliculas().stream()
		// .collect(Collectors.groupingBy((MiembroStaff x) ->
		// x.getDirectores().get(0).getNombre(),
		// Collectors.groupingBy(GestorPeliculasFavoritas::getPeliculas)));

		return getPeliculas().stream().filter((Pelicula x) -> x.getDirectores().size() != 0).collect(
				Collectors.groupingBy((Pelicula x) -> x.getDirectores().get(0).getNombre(), Collectors.toSet()));

	}

	/**
	 * @return Devuelve un Map que relaciona los nombres de los directores con
	 *         la duraci�n media en minutos de las pel�culas dirigidas en
	 *         solitario por dichos directores (es decir, no se incluyen las
	 *         pel�culas codirigidas por varios directores).
	 **/

	public SortedMap<String, Double> getDuracionMediaPorDirector() {

		Map<String, Double> map = getPeliculas().stream()
				.collect(Collectors.groupingBy((Pelicula x) -> x.getDirectores().get(0).getNombre(),
						Collectors.averagingDouble((Pelicula x) -> x.getDuracion().toMinutes())));

		return new TreeMap<>(map);

	}

	/**
	 * @return la pelicula con mas actores en el reparto
	 * 
	 */
	public Pelicula getPeliculaMasActores() {

		Comparator<Pelicula> cmp = Comparator.comparing((Pelicula x) -> x.getActores().size());

		return getPeliculas().stream().max(cmp).orElse(null);

	}

	/**
	 * @param Nombre
	 *            del Actor
	 * @return El conjunto de peliculas del actor pasado como parametro
	 * 
	 */

	public Set<Pelicula> getPeliculasDeActor(String nombreActor) {

		return getPeliculas().stream().filter((Pelicula x) -> x.esActor(nombreActor)).collect(Collectors.toSet());

	}

	/**
	 * @param Nombre
	 *            de un director
	 * @return El conjunto de peliculas del director pasado como parametro
	 */

	public Set<Pelicula> getPeliculasDeDirector(String nombreDirector) {

		return getPeliculas().stream().filter((Pelicula x) -> x.esDirector(nombreDirector)).collect(Collectors.toSet());

	}

	/**
	 * @param Anyo
	 * @return El conjunto de peliculas de un anyo pasado como parametro
	 */

	public Set<Pelicula> getPeliculasPorAnyo(Integer anyo) {

		return getPeliculas().stream().filter((Pelicula x) -> anyo.equals(x.getFechaEstreno().getYear()))
				.collect(Collectors.toSet());

	}
	


	/**
	 * @return Devuelve un map en el que las claves se corresponden con el a�o
	 *         de estreno de la pelicula, y el valor el conjunto de peliculas
	 *         estrenadas ese a�o. El Conjunto de peliculas esta ordenado por la
	 *         fecha de estreno
	 */

	public Map<Integer, SortedSet<Pelicula>> getPeliculasPorAnyo() {

		

		
		return getPeliculas().stream().collect(
				Collectors.groupingBy((Pelicula x) -> x.getFechaEstreno().getYear(), Collectors.toCollection(TreeSet::new)));
	}

}
