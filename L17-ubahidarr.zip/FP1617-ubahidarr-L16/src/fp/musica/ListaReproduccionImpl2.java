package fp.musica;

import java.time.Duration;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import fp.utiles.Imagenes;

public class ListaReproduccionImpl2 extends ListaReproduccionImpl {

	public ListaReproduccionImpl2(String nombre) {
		super(nombre);
	}

	/** Redefinicion de metodos de tratamientos secuenciales **/

	public Set<Artista> getArtistas() {
		return getCanciones().stream().flatMap(x -> x.getArtistas().stream()).collect(Collectors.toSet());

		/*
		 * Set<Artista> result = new HashSet<Artista>();
		 * getCanciones().stream().map(Cancion::getArtistas).forEach(x ->
		 * result.addAll(x)); return result;
		 */
	}

	public void muestraFotoArtista() {
		Comparator<Artista> cmp = Comparator.comparing(x -> x.getNombre());
		getArtistas().stream().filter(x -> x.getURLImagenes().isEmpty()).sorted(cmp)
				.forEach((Artista x) -> Imagenes.show(x.getNombre(), x.getURLImagenes().get(0)));

	}

	public Map<String, List<Cancion>> getCancionesPorArtista() {

		return getCanciones().stream()
				.collect(Collectors.groupingBy((Cancion x) -> x.getArtistas().get(0).getNombre()));

	}

	public Map<String, Long> getNumeroCancionesPorArtista() {

		return getCanciones().stream().collect(
				Collectors.groupingBy((Cancion x) -> x.getArtistas().get(0).getNombre(), Collectors.counting()));

	}

	public Map<String, Integer> getDuracionTotalPorArtista() {
		return getCanciones().stream().filter(c -> c.getArtistas().size() == 1)
				.collect(Collectors.groupingBy((Cancion x) -> x.getArtistas().get(0).getNombre(),
						Collectors.summingInt((Cancion c) -> (int) c.getDuracion().getSeconds())));

		/**
		 * List<Cancion> lista new ArrayList<>(); Integer duracion =
		 * lista.stream().collect(Collectors.summingInt(x -> (int)
		 * x.getDuracion().getSeconds())
		 * 
		 * return getCanciones().stream()
		 * 
		 */

	}

	// - ListaReproduccionImpl2::esAntologia
	public Boolean esAntologia(String artista) {

		return getCanciones().stream().allMatch((Cancion x) -> existeArtista(artista, x.getArtistas()));
	}

	// - ListaReproduccionImpl2::existe (m�todo auxiliar para resolver el
	// anterior)

	// - ListaReproduccionImpl2::contieneArtista
	public Boolean contieneArtista(String artista) {
		return getCanciones().stream().anyMatch(x -> existeArtista(artista, x.getArtistas()));
	}

	/**
	 * @return Cancion con mas Duracion
	 **/

	public Cancion getCancionMasLarga() {

		return getCanciones().stream().max(Comparator.comparing((Cancion x) -> x.getDuracion())).orElse(null);

	}

	/**
	 * @return Cancion con menos Duracion
	 */
	public Cancion getCancionMasCorta() {

		return getCanciones().stream().min(Comparator.comparing((Cancion x) -> x.getDuracion())).orElse(null);

	}

	/**
	 * @return un Duration de la duracion de Lista
	 * 
	 */

	public Duration getDuracion() {

		Long total = getCanciones().stream().collect(Collectors.summingLong((Cancion x) -> x.getDuracion().toMillis()));

		return Duration.ofMillis(total);

	}

	/**
	 * @return un Duration de la duracion media de Lista
	 * 
	 */

	public Duration getDuracionMedia() {

		Double total = getCanciones().stream()
				.collect(Collectors.averagingLong((Cancion x) -> x.getDuracion().toMillis()));

		return Duration.ofMillis(total.longValue());

	}

	/**
	 * @return una sublista de un Artista
	 * 
	 */

	public ListaReproduccion getSubLista(String artista) {

		ListaReproduccion result = new ListaReproduccionImpl2(artista);
		getCanciones().stream().filter((Cancion x) -> existeArtista(artista, x.getArtistas()))
				.collect(Collectors.toList()).forEach(x -> result.incorpora(x));

		return result;

	}

	private Boolean existeArtista(String nombre, List<Artista> l) {
		// 0. Tener claro la fuente de datos para resolver el problema
		// 1. Seleccionar m�todos de stream que solucionen el problema
		// 2. Rellenar los tipos funcionales que necesiten los m�todos

		return l.stream().anyMatch(x -> x.getNombre().equals(nombre));
	}

	public int getPosicionCancion(String tituloCancion) {

		int pos = -1;

		Cancion c = getCanciones().stream().filter(x -> x.getNombre().equals(tituloCancion)).findFirst().orElse(null);

		if (c != null) {
			pos = getCanciones().indexOf(c);
		}

		return pos;

	}

}
