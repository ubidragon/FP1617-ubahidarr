package fp.utiles;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Ficheros {
	public static List<String> leeFichero(String path){
		List<String> res = null;
		try {
			res=Files.readAllLines(Paths.get(path));
		} catch (IOException e) {			
			e.printStackTrace();
			res=new ArrayList<String>();
		}
		return res;
	}
	
	public static <T> List<T> leeFichero(String path, Function<String,T> deString_a_T){
		List<T> res = null;
		try {
			res=Files.lines(Paths.get(path)).map(deString_a_T).collect(Collectors.toList());
		} catch (IOException e) {			
			e.printStackTrace();
			res=new ArrayList<T>();
		}
		return res;
	}
}
