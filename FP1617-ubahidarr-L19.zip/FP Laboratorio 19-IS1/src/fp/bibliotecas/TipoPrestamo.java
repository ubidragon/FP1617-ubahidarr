package fp.bibliotecas;

public enum TipoPrestamo {
	DIARIO, SEMANAL, MENSUAL
}
