package fp.bibliotecas;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import fp.utiles.ConvertLocalDate2String;
import fp.utiles.ConvertString2LocalDate;

/**
 * Tipo que representa un libro. Los libros se ordenan por t�tulo y, a igualdad
 * de t�tulo, por isbn.
 * 
 * @author reinaqu
 *
 */
@JsonIgnoreProperties("diasPrestamo")
public interface Libro extends Comparable<Libro> {

	/**
	 * @return El isbn del libro.
	 */
	String getISBN();

	/**
	 * @return El t�tulo del libro.
	 */
	String getTitulo();

	/**
	 * @return El autor del libro.
	 */
	String getAutor();

	/**
	 * @return El n�jmero de p�ginas del libro.
	 */
	Integer getNumPaginas();

	/**
	 * @return La fecha de adquisici�n del libro.
	 */
	@JsonDeserialize(converter=ConvertString2LocalDate.class)
	@JsonSerialize(converter=ConvertLocalDate2String.class)
	LocalDate getFechaAdquisicion();

	/**
	 * @return El precio del libro.
	 */
	Double getPrecio();

	/**
	 * @return El n�mero de copias que se estima se vender�n del libro.
	 */
	Integer getEstimacionVentas();

	/**
	 * @return true si el libro es un best-seller
	 */
	Boolean esBestSeller();

	/**
	 * @return El tipo de pr�stamo: DIARIO, SEMANAL, MENSUAL
	 */
	TipoPrestamo getTipoPrestamo();

	/**
	 * @param nuevaEstimacion
	 *            Nueva estimaci�n de ventas.
	 * @throws IllegalArgumentException
	 *             si nuevaEstimacion es nulo
	 * @throws IllegalArgumentException
	 *             si nuevaEstimacion no es mayor que cero.
	 */
	void setEstimacionVentas(Integer nuevaEstimacion);

	/**
	 * @param nuevoTipo
	 *            El nuevo tipo de pr�stamo.
	 * @throws IllegalArgumentException
	 *             si nuevoTipo es nulo.
	 */
	void setTipoPrestamo(TipoPrestamo nuevoTipo);

	/**
	 * @return El n�mero de d�as de los que puede disponer un usuario el libro
	 *         una vez que se ha prestado.
	 */
	Integer getDiasPrestamo();
}
