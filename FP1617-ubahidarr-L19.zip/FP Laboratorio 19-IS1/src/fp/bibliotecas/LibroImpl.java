package fp.bibliotecas;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import fp.utiles.Checkers;

/**
 * Clase que implementa al tipo Libro.
 * 
 * @author reinaqu
 *
 */
public class LibroImpl implements Libro {

	private static final Integer MINIMO_COPIAS_BEST_SELLER = 500000;

	private String isbn;
	private String titulo;
	private String autor;
	private Integer numPaginas;
	private LocalDate fechaAdquisicion;
	private Double precio;
	private Integer estimacionVentas;
	private TipoPrestamo tipoPrestamo;

	public LibroImpl(){
		
	}
	
	public LibroImpl(String s) {
		String[] trozos = s.split("#");
		Checkers.check("Formato incorrecto de la cadena de entrada", trozos.length==8);
		
		Integer numPaginas = new Integer(trozos[3].trim());
		LocalDate fechaAdquisicion = LocalDate.parse(trozos[4].trim(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		Integer estimacionVentas = new Integer(trozos[6].trim());
		TipoPrestamo tipoPrestamo = TipoPrestamo.valueOf(trozos[7].trim());
		
		Checkers.checkNoNull("Par�metros nulos", isbn, titulo, autor, numPaginas, fechaAdquisicion, precio,
				estimacionVentas, tipoPrestamo);
		Checkers.check("El n�mero de p�ginas debe ser mayor estrictamente que cero",
				LibroImpl.restriccionNumeroPaginas(numPaginas));
		Checkers.check("La fecha de adquisici�n debe ser anterior o igual a la fecha actual",
				LibroImpl.restriccionFechaAdquisicion(fechaAdquisicion));
		Checkers.check("La estimaci�n de ventas debe ser un valor mayor estricto que cero",
				LibroImpl.restriccionEstimacionVentas(estimacionVentas));
		
		this.isbn = trozos[0].trim();
		this.titulo = trozos[1].trim();
		this.autor = trozos[2].trim();
		this.numPaginas = numPaginas;
		this.fechaAdquisicion = fechaAdquisicion;
		this.precio = new Double(trozos[5].trim());
		this.estimacionVentas = estimacionVentas;
		this.tipoPrestamo = tipoPrestamo;
	}
	
	/**
	 * @param isbn
	 *            El isbn del libro. No puede ser nulo.
	 * @param titulo
	 *            El t�tulo del libro. No puede ser nulo.
	 * @param autor
	 *            El autor del libro. No puede ser nulo.
	 * @param numPaginas
	 *            El n�mero de p�ginas del libro. Ha de ser mayor que cero. No
	 *            puede ser nulo.
	 * @param fechaAdquisicion
	 *            La fecha de adquisici�n del libro. Debe ser anterior o igual a
	 *            la fecha actual. No puede ser nula.
	 * @param precio
	 *            El precio del libro. No puede ser nolo.
	 * @param estimacionVentas.
	 *            La estimaci�n de ventas. Deber mayor que cero. No puede ser
	 *            nulo.
	 * @param tipoPrestamo.
	 *            El tipo de pr�stamo: DIARIO, SEMANAL, MENSUAL. No pude ser
	 *            nulo.
	 */
	public LibroImpl(String isbn, String titulo, String autor, Integer numPaginas, LocalDate fechaAdquisicion,
			Double precio, Integer estimacionVentas, TipoPrestamo tipoPrestamo) {
		//
		Checkers.checkNoNull("Par�metros nulos", isbn, titulo, autor, numPaginas, fechaAdquisicion, precio,
				estimacionVentas, tipoPrestamo);
		Checkers.check("El n�mero de p�ginas debe ser mayor estrictamente que cero",
				LibroImpl.restriccionNumeroPaginas(numPaginas));
		Checkers.check("La fecha de adquisici�n debe ser anterior o igual a la fecha actual",
				LibroImpl.restriccionFechaAdquisicion(fechaAdquisicion));
		Checkers.check("La estimaci�n de ventas debe ser un valor mayor estricto que cero",
				LibroImpl.restriccionEstimacionVentas(estimacionVentas));
		//
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
		this.fechaAdquisicion = fechaAdquisicion;
		this.precio = precio;
		this.estimacionVentas = estimacionVentas;
		this.tipoPrestamo = tipoPrestamo;
	}

	//////////
	// R1: el n�mero de p�ginas debe ser mayor estrictamente que cero.
	// R2: la fecha de adquisici�n debe ser anterior o igual a la fecha actual.
	// R3: la estimaci�n de ventas debe ser un valor mayor estricto que cero.
	private static Boolean restriccionNumeroPaginas(Integer numPaginas) {
		Boolean res;
		res = numPaginas > 0;
		return res;
	}

	private static Boolean restriccionFechaAdquisicion(LocalDate fechaAdquisicion) {
		Boolean res;
		res = fechaAdquisicion.isBefore(LocalDate.now());
		return res;
	}

	private static Boolean restriccionEstimacionVentas(Integer estimacionVentas) {
		Boolean res;
		res = estimacionVentas > 0;
		return res;
	}

	//////////
	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getISBN()
	 */
	public String getISBN() {
		return isbn;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getTitulo()
	 */
	public String getTitulo() {
		return titulo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getAutor()
	 */
	public String getAutor() {
		return autor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getNumPaginas()
	 */
	public Integer getNumPaginas() {
		return numPaginas;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getFechaAdquisicion()
	 */
	public LocalDate getFechaAdquisicion() {
		return fechaAdquisicion;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getPrecio()
	 */
	public Double getPrecio() {
		return precio;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getEstimacionVentas()
	 */
	public Integer getEstimacionVentas() {
		return estimacionVentas;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#esBestSeller()
	 */
	public Boolean esBestSeller() {
		return getEstimacionVentas() >= MINIMO_COPIAS_BEST_SELLER;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getTipoPrestamo()
	 */
	public TipoPrestamo getTipoPrestamo() {
		return tipoPrestamo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#setEstimacionVentas(java.lang.Integer)
	 */
	public void setEstimacionVentas(Integer nuevaEstimacion) {
		Checkers.checkNoNull("Estimaci�n nula", nuevaEstimacion);
		Checkers.check("La estimaci�n de ventas debe ser un valor mayor estricto que cero",
				LibroImpl.restriccionEstimacionVentas(nuevaEstimacion));
		estimacionVentas = nuevaEstimacion;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#setTipoPrestamo(fp.bibliotecas.TipoPrestamo)
	 */
	public void setTipoPrestamo(TipoPrestamo nuevoTipo) {
		Checkers.checkNoNull("nuevoTipo nulo", nuevoTipo);
		tipoPrestamo = nuevoTipo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Libro#getDiasPrestamo()
	 */
	public Integer getDiasPrestamo() {
		Integer numDias = null;

		switch (getTipoPrestamo()) {
		case DIARIO:
			numDias = 1;
			break;
		case SEMANAL:
			numDias = 7;
			break;
		case MENSUAL:
			numDias = 30;
			break;
		}

		return numDias;
	}

	/**
	 * @return La representaci�n como cadena del libro, que est� formada por el
	 *         t�tulo seguido de entre par�ntesis, la palabra ISBN: y el isbn
	 *         del libro.
	 */
	public String toString() {
		return getTitulo() + " (ISBN: " + getISBN() + ")";
	}

	////////////////////////////////////////////////////////////////
	//
	public boolean equals(Object o){
		boolean res = false;
		if(o instanceof Libro){
			Libro l = (Libro) o;
			res = getISBN().equals(l.getISBN()) && getFechaAdquisicion().equals(l.getFechaAdquisicion()) && getTipoPrestamo().equals(l.getTipoPrestamo());
		}
		return res;
	}
	public int hashCode(){
		return this.getISBN().hashCode()+this.getFechaAdquisicion().hashCode()*31+this.getTipoPrestamo().hashCode()*31*31;
	}
	public int compareTo(Libro p){
		int res = this.getFechaAdquisicion().compareTo(p.getFechaAdquisicion());
		if(res == 0){
			res = this.getISBN().compareTo(p.getISBN());
			if(res == 0){
				res = this.getTipoPrestamo().compareTo(p.getTipoPrestamo());
			}
		}
		return res;
	}
}
