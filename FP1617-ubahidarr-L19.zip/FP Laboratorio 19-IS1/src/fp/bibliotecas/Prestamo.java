package fp.bibliotecas;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import fp.utiles.ConvertLocalDate2String;
import fp.utiles.ConvertString2LocalDate;

/**
 * Tipo que representa un pr�stamo de un libro en una biblioteca. Los pr�stamos
 * se ordenan por libro, por usuario y por fecha de pr�stamo.
 * 
 * @author reinaqu
 *
 */
@JsonIgnoreProperties("fechaDevolucion")
public interface Prestamo extends Comparable<Prestamo> {

	/**
	 * @return El usuario que realiza el pr�stamo.
	 */
	Persona getUsuario();

	/**
	 * @return El libro prestado.
	 */
	Libro getLibro();

	/**
	 * @return La fecha en la que se realiza el pr�stamo.
	 */
	@JsonDeserialize(converter=ConvertString2LocalDate.class)
	@JsonSerialize(converter=ConvertLocalDate2String.class)
	
	LocalDate getFechaPrestamo();

	/**
	 * @return La fecha l�mite para la devoluci�n del pr�stamo.
	 */
//	@JsonDeserialize(converter=ConvertString2LocalDate.class)
//	@JsonSerialize(converter=ConvertLocalDate2String.class)
	LocalDate getFechaDevolucion();

	/**
	 * @param fecha La nueva fecha del pr�stamo.
	 * @throws IllegalArgumentException si fecha es nula.
	 * @throws IllegalArgumentException si fecha es posterior a la fecha actual.
	 */
	void setFechaPrestamo(LocalDate fecha);
}
