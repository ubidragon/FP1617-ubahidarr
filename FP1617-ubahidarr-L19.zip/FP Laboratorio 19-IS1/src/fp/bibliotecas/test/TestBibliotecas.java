package fp.bibliotecas.test;

import java.time.LocalDate;

import fp.bibliotecas.Libro;
import fp.bibliotecas.LibroImpl;
import fp.bibliotecas.Persona;
import fp.bibliotecas.PersonaImpl;
import fp.bibliotecas.Prestamo;
import fp.bibliotecas.PrestamoImpl;
import fp.bibliotecas.TipoPrestamo;
import fp.utiles.UtilesJSon;

public class TestBibliotecas {

	public static void main(String[] args) {

		Libro l1 = new LibroImpl("978-84-15177-91-1", "Libro 1", "Autor 1", 199, LocalDate.of(2016, 02, 01), 15.0, 200,
				TipoPrestamo.MENSUAL);

		Persona p1 = new PersonaImpl("31565431R", "Juan", "Perugorria Garcia", LocalDate.of(1996, 2, 29),
				"juan.perugorria@gmail.com");

		Prestamo pr1 = new PrestamoImpl(p1, l1, LocalDate.of(2016, 07, 01));
		System.out.println(pr1);
		testSerializacionLibro(l1);
		testSerializacionPrestamo(pr1);
		//testSerializacionPersona(p1);

	}
	//Deserializacion para poder encontrar fallos
//	private static void testSerializacionPersona(Persona p) {
//		System.out.println("\nSerializando persona:");
//		// 1: Serializar la persona p y mostrar el resultado en consola.
//
//		String json = UtilesJSon.toJSON(p);
//		System.out.println(json);
//
//		System.out.println("\nDeserializando el JSON anterior:");
//		// 2: Deserializar el JSON anterior y mostrar el objeto Persona
//		// obtenido.
//		Persona clon = UtilesJSon.fromJSON(json, PersonaImpl.class);
//		mostrar(clon);
//	}

	private static void testSerializacionPrestamo(Prestamo p1) {

		System.out.println("\nSerializando Prestamo:");
		String json = UtilesJSon.toJSON(p1);
		System.out.println(json);

		System.out.println("\nDeserializando el JSON anterior:");
		Prestamo clon = UtilesJSon.fromJSON(json, PrestamoImpl.class);
		mostrarPrestamo(clon);

	}

	private static void testSerializacionLibro(Libro l1) {

		System.out.println("\nSerializando Libro:");
		String json = UtilesJSon.toJSON(l1);
		System.out.println(json);

		System.out.println("\nDeserializando el JSON anterior:");
		Libro clon = UtilesJSon.fromJSON(json, LibroImpl.class);
		mostrarLibro(clon);

	}

	private static void mostrarLibro(Libro l) {

		System.out.println("ISBN: " + l.getISBN());
		System.out.println("Titulo del Libro: " + l.getTitulo());
		System.out.println("Autor del Libro: " + l.getAutor());
		System.out.println("Paginas del Libro: " + l.getNumPaginas());
		System.out.println("Fecha de Adquisicion: " + l.getFechaAdquisicion());
		System.out.println("Precio: " + l.getPrecio());
		System.out.println("Ventas: " + l.getEstimacionVentas());
		System.out.println("Prestamo: " + l.getTipoPrestamo());
		System.out.println("Dias de Prestamo: " + l.getDiasPrestamo());

	}

	private static void mostrarPrestamo(Prestamo pr) {
		System.out.println("Usuario: " + pr.getUsuario());
		System.out.println("Libro: " + pr.getLibro());
		System.out.println("Fecha Prestamo: " + pr.getFechaPrestamo());
//		System.out.println("Fecha Devolucion: " + pr.getFechaDevolucion());

	}
	
	private static void mostrar(Persona p) {
		System.out.println("Persona: " + p);
		System.out.println("Nombre: " + p.getNombre());
		System.out.println("Apellidos: " + p.getApellidos());
		System.out.println("DNI: " + p.getDNI());
		System.out.println("Fecha de nacimiento: " + p.getFechaNacimiento());
		System.out.println("Edad: " + p.getEdad());
		System.out.println("Email: " + p.getEmail());
	}

}