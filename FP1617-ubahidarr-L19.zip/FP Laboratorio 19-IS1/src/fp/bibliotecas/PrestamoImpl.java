package fp.bibliotecas;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import fp.utiles.Checkers;

/**
 * Clase que implementa a Prestamo
 * 
 * @author reinaqu
 *
 */

public class PrestamoImpl implements Prestamo {
	@JsonDeserialize(as= PersonaImpl.class)
	private Persona usuario;
	@JsonDeserialize(as= LibroImpl.class)
	private Libro libro;
	private LocalDate fechaPrestamo;

	public PrestamoImpl(){
		
	}
	
	
	/**
	 * @param usuario
	 *            El usuario que realiza el pr�stamo.
	 * @param libro
	 *            El libro prestado.
	 * @param fechaPrestamo
	 *            La fecha en la que se realiza el pr�stamo.
	 * @throws IllegalArgumentException
	 *             si alguno de los par�metros es nulo.
	 * @throws IllegalArgumentException
	 *             si fechaPrestamo es posterio a la fecha actual.
	 */
	public PrestamoImpl(Persona usuario, Libro libro, LocalDate fechaPrestamo) {
		//
		Checkers.checkNoNull("Par�metros nulos", usuario, libro, fechaPrestamo);
		Checkers.check("La fecha de pr�stamo debe ser anterior o igual a la fecha actual",
				PrestamoImpl.restriccionFechaPrestamo(fechaPrestamo));
		//
		this.usuario = usuario;
		this.libro = libro;
		this.fechaPrestamo = fechaPrestamo;
	}

	//////////
	// R1: la fecha de pr�stamo debe ser anterior o igual a la fecha actual.
	private static Boolean restriccionFechaPrestamo(LocalDate fechaPrestamo) {
		Boolean res;
		res = fechaPrestamo.compareTo(LocalDate.now()) <= 0;
		return res;
	}

	//////////
	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Prestamo#getFechaPrestamo()
	 */
	public LocalDate getFechaPrestamo() {
		return fechaPrestamo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Prestamo#setFechaPrestamo(java.time.LocalDate)
	 */
	public void setFechaPrestamo(LocalDate fechaPrestamo) {
		Checkers.checkNoNull("FechaPrestamo nula", fechaPrestamo);
		Checkers.check("La fecha de pr�stamo debe ser anterior o igual a la fecha actual",
				PrestamoImpl.restriccionFechaPrestamo(fechaPrestamo));
		this.fechaPrestamo = fechaPrestamo;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Prestamo#getUsuario()
	 */
	public Persona getUsuario() {
		return usuario;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Prestamo#getLibro()
	 */
	public Libro getLibro() {
		return libro;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see fp.bibliotecas.Prestamo#getFechaDevolucion()
	 */
	public LocalDate getFechaDevolucion() {
		return getFechaPrestamo().plusDays(getLibro().getDiasPrestamo());
	}

	/**
	 * @return La representaci�n como cadena de un usuario, que est� formada
	 *         por: - El t�tulo del libro - El dni del usuario - La fecha del
	 *         pr�stamo - La fecha de devoluci�n.
	 */
	public String toString() {
		return getLibro().getTitulo() + " (usuario:" + getUsuario().getDNI() + "; fecha pr�stamo:"
				+ getFechaPrestamo().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "; fecha devoluci�n:"
				+ getFechaDevolucion().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	}

	////////////////////////////////////////////////////////////////
	//
	/**
	 * @return true si dos objetos son iguales. Dos pr�stamos son iguales si
	 *         hacen referencia al mismo libro, al mismo usuario y tienen la
	 *         misma fecha de pr�stamo.
	 */
	public boolean equals(Object o) {
		boolean res = false;
		if (o instanceof Prestamo) {
			boolean aux1 = this.getLibro().equals(((Prestamo) o).getLibro());
			boolean aux2 = this.getUsuario().equals(((Prestamo) o).getUsuario());
			boolean aux3 = this.getFechaPrestamo().equals(((Prestamo) o).getFechaPrestamo());
			res = aux1 && aux2 && aux3;
		}
		return res;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.getLibro().hashCode() + this.getUsuario().hashCode() * 31
				+ this.getFechaPrestamo().hashCode() * 31 * 31;
	}

	/**
	 * El critero de orden de los pr�stamos es por libro; a igualdad de libro,
	 * por usuario; y a igualdad de usuario, por la fecha de pr�stamo.
	 */
	public int compareTo(Prestamo p) {
		int res = this.getLibro().compareTo(p.getLibro());
		if (res == 0) {
			res = this.getUsuario().compareTo(p.getUsuario());
			if (res == 0) {
				res = this.getFechaPrestamo().compareTo(p.getFechaPrestamo());
			}
		}
		return res;
	}

}
