package fp.ciclismo;

import java.time.Duration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import fp.utiles.ConvertString2Duration;


@JsonIgnoreProperties("velocidadMedia")
public interface Ganador {
	Integer getAnyo();
	String getNacionalidad();
	String getNombre();
	String getEquipo();
	Integer getKmRecorridos();
//	@JsonDeserialize(converter=ConvertString2Duration.class)
	Duration getTiempoEmpleado();
	Integer getNumEtapasGanadas();
	Integer getNumDiasMaillot();
	Double getVelocidadMedia();
}
