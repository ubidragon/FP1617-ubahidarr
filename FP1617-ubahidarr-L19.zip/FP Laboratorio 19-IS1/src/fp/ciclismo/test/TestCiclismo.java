package fp.ciclismo.test;

import java.util.List;

import fp.ciclismo.EstadisticasCarrera;
import fp.ciclismo.EstadisticasCarreraImpl;
import fp.ciclismo.FactoriaCiclismo;
import fp.ciclismo.Ganador;
import fp.ciclismo.GanadorImpl;
import fp.utiles.UtilesJSon;

public class TestCiclismo {

	public static void main(String[] args) {
		EstadisticasCarrera est = FactoriaCiclismo.creaEstadisticas2006_16();

		System.out.println(est);
//		testSerializacionGanador(est.getGanadores().get(0));
	testSerializacionEstadisticas(est);
	}

	private static void testSerializacionGanador(Ganador ganador) {
		System.out.println("\nSerializando Ganador:");
		String json = UtilesJSon.toJSON(ganador);
		System.out.println(json);

		System.out.println("\nDeserializando el JSON anterior:");
		Ganador clon = UtilesJSon.fromJSON(json, GanadorImpl.class);
		mostrarGanador(clon);

	}

	private static void testSerializacionEstadisticas(EstadisticasCarrera est) {
		System.out.println("\nSerializando Estadisticas:");
		String json = UtilesJSon.toJSON(est);
		System.out.println(json);

		System.out.println("\nDeserializando el JSON anterior:");
		EstadisticasCarrera clon = UtilesJSon.fromJSON(json, EstadisticasCarreraImpl.class);
		showEstats(clon);

	}

	private static void showEstats(EstadisticasCarrera stats) {
		System.out.println("Nombre Carrera: " + stats.getNombreCarrera());
		System.out.println("Ganadores: " + stats.getGanadores().get(0));
	}

	private static void mostrarGanador(Ganador win) {

		System.out.println("Anyo: " + win.getAnyo());
		System.out.println("Pais: " + win.getNacionalidad());
		System.out.println("Nombre: " + win.getNombre());
		System.out.println("Equipo: " + win.getEquipo());
		System.out.println("KM: " + win.getKmRecorridos());
		System.out.println("Tiempo: " + win.getTiempoEmpleado());
		System.out.println("Etapas Ganadas: " + win.getNumEtapasGanadas());
		System.out.println("Dias Maillot Amarillo: " + win.getNumDiasMaillot());

	}

}
