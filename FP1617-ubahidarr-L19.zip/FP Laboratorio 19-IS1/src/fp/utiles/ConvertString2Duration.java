package fp.utiles;

import java.time.Duration;

import com.fasterxml.jackson.databind.util.StdConverter;

public class ConvertString2Duration  extends StdConverter<String, Duration>{
	
	public Duration convert(String s){
		return Duration.ofSeconds(new Long(s));
	}

}
