package fp.utiles;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.databind.util.StdConverter;

public class ConvertString2LocalDateTime extends StdConverter<String, LocalDateTime> {

	@Override
	public LocalDateTime convert(String s) {

		DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

		return LocalDateTime.parse(s, dateformat);
	}
}
