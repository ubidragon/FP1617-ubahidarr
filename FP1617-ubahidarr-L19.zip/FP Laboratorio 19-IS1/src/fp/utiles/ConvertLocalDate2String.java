package fp.utiles;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.databind.util.StdConverter;

public class ConvertLocalDate2String extends StdConverter<LocalDate,String>{

	@Override
	public String convert(LocalDate date) {
		
		DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		return date.format(dateformat);
	}

}
