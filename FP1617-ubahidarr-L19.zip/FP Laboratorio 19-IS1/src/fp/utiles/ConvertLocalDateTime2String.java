package fp.utiles;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.databind.util.StdConverter;

public class ConvertLocalDateTime2String extends StdConverter<LocalDateTime,String>{

	@Override
	public String convert(LocalDateTime date) {
		
		DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
		
		return date.format(dateformat);
	}



}